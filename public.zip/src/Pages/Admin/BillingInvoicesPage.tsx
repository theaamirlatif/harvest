import BillingInvoices from "@components/Admin/Transactions/BillingInvoices";

const BillingInvoicesPage = () => {
  return (
    <div>
      <BillingInvoices />
    </div>
  );
};

export default BillingInvoicesPage;

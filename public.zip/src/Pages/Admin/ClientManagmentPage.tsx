import ClientManagement from "@components/Admin/Sellers/ClientManagement";

const ClientManagmentPage = () => {
  return (
    <>
      <ClientManagement />
    </>
  );
};

export default ClientManagmentPage;

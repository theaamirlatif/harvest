import Documents from '@components/Admin/Transactions/Documents'

const DocumentsPage = () => {
  return (
   <>
   <Documents/>
   </>
  )
}

export default DocumentsPage
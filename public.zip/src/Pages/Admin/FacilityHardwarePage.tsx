import FacilityHardware from "@components/Admin/LisitngDetail/FacilityHardware";

const FacilityHardwarePage = () => {
  return (
    <div>
      <FacilityHardware />
    </div>
  );
};

export default FacilityHardwarePage;

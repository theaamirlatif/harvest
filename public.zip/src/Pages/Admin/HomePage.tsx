import Dashboard from '@components/Admin/Dashboard'

const HomePage = () => {
  return (
    <>
    <Dashboard/>
    </>
  )
}

export default HomePage
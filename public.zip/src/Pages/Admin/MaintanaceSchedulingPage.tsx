import MaintanaceScheduling from "@components/Admin/SellerDetail/MaintanaceScheduling";

const MaintanaceSchedulingPage = () => {
  return (
    <>
      <MaintanaceScheduling />
    </>
  );
};

export default MaintanaceSchedulingPage;

import Notification from "@components/Admin/Notification";

const NotificationPage = () => {
  return (
    <>
      <Notification />
    </>
  );
};

export default NotificationPage;

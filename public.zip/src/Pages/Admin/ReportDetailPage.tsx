import ReportDetail from "@components/Admin/ReportDetail";

const ReportDetailPage = () => {
  return (
    <>
      <ReportDetail />
    </>
  );
};

export default ReportDetailPage;

import RequestAlerts from "@components/Admin/Listings/RequestAlerts";

const RequestAlertsPage = () => {
  return (
    <>
      <RequestAlerts />
    </>
  );
};

export default RequestAlertsPage;

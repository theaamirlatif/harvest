import Settings from "@components/Admin/Settings"

const SettingsPage = () => {
  return (
    <>
      <Settings />
    </>
  )
}

export default SettingsPage
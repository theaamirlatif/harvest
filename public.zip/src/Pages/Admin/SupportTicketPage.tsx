import SupportTicket from "@components/Admin/Reports/SupportTicket";

const SupportTicketPage = () => {
  return (
    <>
      <SupportTicket />
    </>
  );
};

export default SupportTicketPage;

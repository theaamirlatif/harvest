import TicketDetail from "@components/Admin/TicketDetail";

const TicketDetailPage = () => {
  return (
    <div>
      <TicketDetail />
    </div>
  );
};

export default TicketDetailPage;

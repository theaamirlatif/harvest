import Tickets from "@components/Admin/Tickets";

const TicketsPage = () => {
  return (
    <>
      <Tickets />
    </>
  );
};

export default TicketsPage;

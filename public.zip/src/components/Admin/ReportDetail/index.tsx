// import SellerReport from "./SellerReport";
// import ReviewDetail from "./ReviewDetail";
// import ListingReport from "./ListingReport";

const ReportDetail = () => {
  return (
    <div>
      {/* <SellerReport /> */}
      {/* <ReviewDetail/> */}
      {/* <ListingReport /> */}
    </div>
  );
};

export default ReportDetail;
